/*
AUTORES: 
        JUAN FRANCISCO HERNANDEZ FERNANDEZ
        MACIÀ SALVÀ SALVÀ
        ALEJANDRO MUÑOZ NAVARRO
 */
package compilador.sintactic.symbols;

public class SymbolI extends SymbolBase {

    public SymbolI(String name, Integer id) {
        super(name, id);
    }

    public SymbolI() {
        super("I", 0);
    }

}
