/*
AUTORES: 
        JUAN FRANCISCO HERNANDEZ FERNANDEZ
        MACIÀ SALVÀ SALVÀ
        ALEJANDRO MUÑOZ NAVARRO
 */
package compilador.sintactic.symbols;

public class SymbolEB extends SymbolBase {

    public SymbolEB(String name, Integer id) {
        super(name, id);
    }

    public SymbolEB() {
        super("EB", 0);
    }

}
