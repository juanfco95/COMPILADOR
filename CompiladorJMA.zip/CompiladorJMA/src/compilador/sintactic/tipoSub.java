/*
AUTORES: 
        JUAN FRANCISCO HERNANDEZ FERNANDEZ
        MACIÀ SALVÀ SALVÀ
        ALEJANDRO MUÑOZ NAVARRO
 */
package compilador.sintactic;

public enum tipoSub {
    tipoSubBool,
    tipoSubInt,
    tipoSubVoid
}
