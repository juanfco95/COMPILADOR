/*
AUTORES: 
        JUAN FRANCISCO HERNANDEZ FERNANDEZ
        MACIÀ SALVÀ SALVÀ
        ALEJANDRO MUÑOZ NAVARRO
 */
package compilador.sintactic;

public class declaracion {

    public int np; //ambit
    public descripcion d; //tipus 
    public String id; //nom

    public declaracion() {
        //Constructor vacio
    }

}
