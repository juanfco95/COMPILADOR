package compilador.sintactic;

/*
AUTORES: 
        JUAN FRANCISCO HERNANDEZ FERNANDEZ
        MACIÀ SALVÀ SALVÀ
        ALEJANDRO MUÑOZ NAVARRO
 */
enum tipoDescripcion {
    Constant,
    Variable,
    IdNull,
    Proc,
    Arg_in,
    Arg
}
