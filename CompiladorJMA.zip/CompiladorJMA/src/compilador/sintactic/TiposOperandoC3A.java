/*
AUTORES: 
        JUAN FRANCISCO HERNANDEZ FERNANDEZ
        MACIÀ SALVÀ SALVÀ
        ALEJANDRO MUÑOZ NAVARRO
 */
package compilador.sintactic;

public enum TiposOperandoC3A {
    variable, procedure, parametro, enteroLit, booleano, etiqueta, Constant
}
