/*
AUTORES: 
        JUAN FRANCISCO HERNANDEZ FERNANDEZ
        MACIÀ SALVÀ SALVÀ
        ALEJANDRO MUÑOZ NAVARRO
 */
package compilador.sintactic;

public enum TiposInstruccionC3A {
    //AQUI TENEMOS QUE METER TODOS LOS TIPOS DE OPERACION QUE ADMITE NUESTRO CODIGO DE 3@ 
    ADD,
    SUB,
    MUL,
    DIV,
    MOD,
    AND,
    OR,
    LT,
    LE,
    EQ,
    NE,
    GE,
    GT,
    IFGT,
    ASSIG,
    GOTO,
    SKIP,
    COPY,
    CALL,
    PARAM_S,
    PMB,
    RTN
}
