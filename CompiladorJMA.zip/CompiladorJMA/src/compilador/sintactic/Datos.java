/*
AUTORES: 
        JUAN FRANCISCO HERNANDEZ FERNANDEZ
        MACIÀ SALVÀ SALVÀ
        ALEJANDRO MUÑOZ NAVARRO
 */
package compilador.sintactic;

import java.util.ArrayList;

public class Datos {

    public int nivel;
    public ArrayList<variable> tv = new ArrayList<>();
    public ArrayList<Procedimiento> tp = new ArrayList<>();
}
